package material_EXAMEN;

public class Personas {

	public void anadir(Persona persona) {
		// TODO Auto-generated method stub
		
	}
	

}
